x = 1
sum = 0
for x in range (101):
    sum = sum + x
print(sum)