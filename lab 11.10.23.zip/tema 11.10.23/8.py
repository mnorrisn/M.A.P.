n = int(input())
if n % 2 == 0:
    print("par")
else:
    print("impar")