n = int(input())
if n > 0:
    print(str(n) + " este pozitiv")
elif n < 0:
    print(str(n) + " este negativ")
else:
    print(str(n) + " este 0 (wow)")