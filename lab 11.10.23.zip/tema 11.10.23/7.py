zi = int(input())
if zi == 1:
    print("Luni")
elif zi == 2:
    print("Marti")
elif zi == 3:
    print("Miercuri")
elif zi == 4:
    print("Joi")
elif zi == 5:
    print("Vineri")
elif zi == 6:
    print("Sambata")
elif zi == 7:
    print("Duminica")
else:
    print("Paote pe alta planeta, dar aici nu avem acea zi din saptamana")