an = int(input())
if an % 4 == 0:
    print("an bisect")
else:
    print("an normal")